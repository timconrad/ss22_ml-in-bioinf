from .KFold import KFold
from .holdout import holdout

__all__ = ["kfold", "holdout"]
