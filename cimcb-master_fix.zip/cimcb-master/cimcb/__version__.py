from __future__ import division, absolute_import, print_function

major = 2
minor = 1
micro = 2
version = "%(major)d.%(minor)d.%(micro)d" % (locals())
